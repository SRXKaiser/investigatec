
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from app.core.config import settings
from app.db.session import engine

from app.api.auth import router as auth_router
from app.api.perfiles import router as perfiles_router
from app.api.academico import router as academico_router
from app.api.roles import router as roles_router
from app.api.administracion import router as administracion_router
from app.api.proyectos import router as proyectos_router
from app.api.archivos import router as archivos_router
from app.api.revisiones import router as revisiones_router
from app.api.notificaciones import router as notificaciones_router
from app.api.asignaciones import router as asignaciones_router
from app.api.seguimiento import router as seguimiento_router


app = FastAPI(
    title="InvestigaTec API",
    description="Sistema de gestion y revision de proyectos del Cuerpo Academico",
    version="2.0.0",
)

app.include_router(auth_router)
app.include_router(perfiles_router)
app.include_router(academico_router)
app.include_router(roles_router)
app.include_router(administracion_router)
app.include_router(proyectos_router)
app.include_router(archivos_router)
app.include_router(revisiones_router)
app.include_router(notificaciones_router)
app.include_router(asignaciones_router)
app.include_router(seguimiento_router)

origins = [
    origin.strip()
    for origin in settings.cors_origins.split(",")
    if origin.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {
        "mensaje": "Bienvenido a InvestigaTec API",
        "version": "2.0.0",
    }


@app.get("/health")
def health():
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))

        return {
            "api": "ok",
            "database": "connected",
        }

    except SQLAlchemyError:
        return {
            "api": "ok",
            "database": "disconnected",
        }
